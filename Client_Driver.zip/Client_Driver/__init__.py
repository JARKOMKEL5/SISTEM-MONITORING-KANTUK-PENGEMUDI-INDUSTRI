# === File: drowsiness_detector/__init__.py ===
from .core import DrowsinessDetector